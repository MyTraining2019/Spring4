package org.cap.model;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.context.support.FileSystemXmlApplicationContext;
import org.springframework.core.io.ClassPathResource;

public class TestClass {

	public static void main(String[] args) {
		
		ApplicationContext context=new ClassPathXmlApplicationContext("myBeans.xml");
		//ApplicationContext context=new FileSystemXmlApplicationContext("D:\\Users\\vidavid\\Desktop\\myBeans.xml");
		//BeanFactory context=new XmlBeanFactory(new ClassPathResource("myBeans.xml"));
		Employee employee=(Employee) context.getBean("employee");

		System.out.println(employee);
	}

}
