package org.cap.boot;

import org.cap.demo.AppConfig;
import org.cap.service.FileService;
import org.cap.service.FileServiceImpl;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class MainClass {

	public static void main(String[] args) {
		
		AnnotationConfigApplicationContext context=new AnnotationConfigApplicationContext(AppConfig.class);
		
		FileService fileService=(FileService)context.getBean("fileService");
		
		fileService.readFile();
		
	}

}
