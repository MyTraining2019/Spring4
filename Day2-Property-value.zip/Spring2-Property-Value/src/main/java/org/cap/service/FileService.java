package org.cap.service;

public interface FileService {
	
	void readFile();

}
