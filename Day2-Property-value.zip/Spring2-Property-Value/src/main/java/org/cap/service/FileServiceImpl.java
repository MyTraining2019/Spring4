package org.cap.service;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;

@Service("fileService")
public class FileServiceImpl implements FileService{
	
	@Value("${jdbc.driver:default}")
	private String jdbcUrl;
	
	@Value("${fileLocation:c:/temp/outputData}")
	private String fileLocation;
	
	@Autowired
	private Environment environment;

	@Override
	public void readFile() {
		
		System.out.println("Read My File content");
		String fileLoc=environment.getProperty("fileLocation");
		System.out.println("File Location:" + fileLoc);
		
		System.out.println("File Location:" + fileLocation);
		System.out.println("JDBC URl:" + jdbcUrl);
	}

}
