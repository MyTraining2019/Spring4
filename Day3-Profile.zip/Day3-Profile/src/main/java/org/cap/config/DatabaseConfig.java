package org.cap.config;

import javax.sql.DataSource;

public interface DatabaseConfig {
	
	DataSource getDatSource();

}
