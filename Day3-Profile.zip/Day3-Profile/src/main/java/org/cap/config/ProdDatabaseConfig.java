package org.cap.config;

import javax.sql.DataSource;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;
import org.springframework.jdbc.datasource.DriverManagerDataSource;

@Profile("production")
@Configuration
public class ProdDatabaseConfig implements DatabaseConfig {

	
	DriverManagerDataSource dataSource=new DriverManagerDataSource();

	@Bean
	@Override
	public DataSource getDatSource() {
		System.out.println("Create DataSource - Production");
		///
		//
		//
		return dataSource;
	}

}
