package org.cap.boot;

import java.util.List;

import org.cap.config.AppConfig;
import org.cap.model.Book;
import org.cap.service.BookService;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class MainClass {

	public static void main(String[] args) {
		
		AnnotationConfigApplicationContext context=new AnnotationConfigApplicationContext(AppConfig.class);
		
		BookService bookService=(BookService)context.getBean("bookService");
		
		/*//bookService.createBookTable();
		Book book=new Book(11, "Oracle Complete ref", "Thomson", 340);
		Book book1=new Book(12, "SCJP", "Kathey Sera", 560);
		Book book2=new Book(13, "Head First Java", "Jack", 700);
		Book book3=new Book(145, "Head First Servlets", "Tom", 900);*/
		//Book book4=new Book(101, "Design Principles of CSS", "Emi", 1200);
		
		
	/*	bookService.addBook(book);
		bookService.addBook(book1);
		bookService.addBook(book2);
		bookService.addBook(book3);*/
		//bookService.addBook(book4);
		
		
		
		
		//bookService.deleteBook(1);
		
		/*int count=bookService.getNoOfRows();
		
		System.out.println("Total no of Records: " + count);
		
		String bookName=bookService.getBookName(13);
		System.out.println("Book Name: " + bookName);*/
		
		/*Book book=bookService.findBook(13);
		System.out.println(book);*/
		
		List<Book> books=bookService.getAllBook();
		
		
		for(Book book:books){
			System.out.println(book);
		}
		
	
		
		
		
		
	}

}
