package org.cap.dao;

import java.util.List;

import org.cap.model.Book;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

@Repository
@Qualifier("bookDao")
public class BookDaoImpl implements BookDao {
	
	@Autowired
	private JdbcTemplate jdbcTemp;

	@Override
	public void createBookTable() {
		String sql="create table book(bookId int primary key,"
				+ "bookName varchar(25), author varchar(15),"
				+ "price numeric(8,2))";
		jdbcTemp.execute(sql);
		
		System.out.println("Table Created");
	}

	@Override
	public void addBook(Book book) {
		String sql="insert into book values(?,?,?,?)";
		jdbcTemp.update(sql,book.getBookId(),book.getBookName(),book.getAuthor(),
				book.getPrice());
		
		/*jdbcTemp.update(sql,new Object[]{book.getBookId(),book.getBookName(),book.getAuthor(),
				book.getPrice()});
		*/
		
		System.out.println("Book Inserted");
		
	}

	@Override
	public void deleteBook(int bookId) {
		
		
		String sql="delete from book where bookId=?";
		int count=jdbcTemp.update(sql,bookId);
		System.out.println("Book Deleted -->" + count);
	}

	@Override
	public int getNoOfRows() {
		String sql="select count(*) from book";
		int count=jdbcTemp.queryForObject(sql, Integer.class);
		
		return count;
	}

	
	@Override
	public String getBookName(int bookId) {
		String sql="select bookName from book where bookId=? ";
		String bookName=jdbcTemp.queryForObject(sql,new Object[]{bookId}, String.class);
		return bookName;
	}

	@Override
	public Book findBook(int bookId) {
		String sql="select * from book where bookId=?";
		Book book=jdbcTemp.queryForObject(sql, new Object[]{bookId},new BeanPropertyRowMapper<>(Book.class));
		return book;
	}

	@Override
	public List<Book> getAllBook() {
		String sql="select * from book";
		//List<Object> books=jdbcTemp.queryForList(sql,new BeanPropertyRowMapper<>(Book.class));
		List<Book> books=jdbcTemp.query(sql, new BeanPropertyRowMapper<>(Book.class));
		
		return books;
		
		
	}
}
