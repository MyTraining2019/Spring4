package org.cap.service;

import java.util.List;

import org.cap.model.Book;

public interface BookService {
	public void createBookTable();
	
	public void addBook(Book book);
	
	public void deleteBook(int bookId);
	public int getNoOfRows();
	public String getBookName(int bookId);
	public Book findBook(int bookId);
	
	public List<Book> getAllBook();
}
