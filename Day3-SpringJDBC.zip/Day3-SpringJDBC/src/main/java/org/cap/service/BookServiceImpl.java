package org.cap.service;



import java.util.List;

import org.cap.dao.BookDao;
import org.cap.model.Book;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service("bookService")
public class BookServiceImpl implements BookService{
	
	@Autowired
	private BookDao bookDao;

	@Override
	public void createBookTable() {
		bookDao.createBookTable();
	}

	@Override
	public void addBook(Book book) {
		bookDao.addBook(book);
		
	}

	@Override
	public void deleteBook(int bookId) {
		bookDao.deleteBook(bookId);
	}

	@Override
	public int getNoOfRows() {
		
		return bookDao.getNoOfRows();
	}

	@Override
	public String getBookName(int bookId) {
		
		return bookDao.getBookName(bookId);
	}

	@Override
	public Book findBook(int bookId) {
		// TODO Auto-generated method stub
		return bookDao.findBook(bookId);
	}

	@Override
	public List<Book> getAllBook() {
		
		return bookDao.getAllBook();
	}


	
}
