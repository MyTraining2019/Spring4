package org.cap.boot;

import org.springframework.context.support.ClassPathXmlApplicationContext;

import org.cap.dao.IPersonDao;
import org.cap.model.Person;

public class TestSpringJDBCTemplate {
	public static void main(String[] args){
		ClassPathXmlApplicationContext applicationContext = 
				new ClassPathXmlApplicationContext("application-config.xml");

			IPersonDao personDAO = applicationContext.
				getBean("personDao", IPersonDao.class);
			
			Person person = new Person("Jack kfh idhfkj hfjd hfjdshfkjh sfhskj hkjds hfkjshfkjdshfkdsf khfkjhfdk sdkhf","Jerry","John st.","NY", "NY", "USA");
			
			//Insert user to the table 3 times:
			for (int i = 0; i < 3; i++) {
			    personDAO.insertUser(person); 
			}
			
			//Delete first person from table
			personDAO.deletePerson(1);
				
			//Select all inserted user from the table
			personDAO.selectAllPerson();	
			
			//Select data from tabel where person 
			//name is "Jack"
			personDAO.selectPersonByName();
			

			applicationContext.close();

		    }
	}


