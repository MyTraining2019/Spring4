package org.cap.dao;

import org.cap.model.Person;

public interface IPersonDao {
	int insertUser(Person person);
    void deletePerson(int personID);
    void selectAllPerson();
    void selectPersonByName();
    
}
