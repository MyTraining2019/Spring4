package org.cap.dao;

import java.sql.Types;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.TransactionStatus;
import org.springframework.transaction.support.TransactionCallback;
import org.springframework.transaction.support.TransactionCallbackWithoutResult;
import org.springframework.transaction.support.TransactionTemplate;

import org.cap.model.Person;

public class PersonDaoImpl implements IPersonDao{
	 private JdbcTemplate jdbcTemplate;
	    private TransactionTemplate transactionTemplate;
	    
	    private PlatformTransactionManager transactionManager;

	  
	    public int insertUser(final Person person) {
		
		//insert statement returns results so we are using 
		//TransactionCallback
		return transactionTemplate.execute(new 
			TransactionCallback<Integer>() {

		
		    public Integer doInTransaction(TransactionStatus transactionStatus) {
			try {
				
				String sql="update book  set price=? where bookId=?";
				
				jdbcTemplate.update(sql,new Object[]{1200,145});
				
				
			    String inserQuery = "INSERT INTO person(First_Name,"
			    	+ " Last_Name, Street_Name, City, State, Country)"
			    	+ " VALUES(?, ?, ?, ?, ?, ?)";
			    
			    
			    Object[] params = new Object[] { person.getFirstName(),
				    person.getLastName(),
				    person.getStreet(), person.getCity(),
				    person.getState(),
				    person.getCountry() };
			    
			    
			    int[] types = new int[] { Types.VARCHAR, Types.VARCHAR,
				    Types.VARCHAR,
				    Types.VARCHAR, Types.VARCHAR,
				    Types.VARCHAR };
			    
			    
			    
			    int value = jdbcTemplate.update(inserQuery, params,
				    types);
			    
			    //transactionManager.commit(transactionStatus);
			    System.out.println("\nPerson inserted to the table");
			    return value;
			} catch (Exception e) {
				System.out.println(e.getMessage());
				System.out.println("\nPerson insertion Failed");
			  // transactionStatus.setRollbackOnly();
			}
			return 0;
		    }

		});
		
	    }
	    
	    
	    
	    
	    
	    
	    
	    
	    

	  
	    public void deletePerson(final int personID) {
		
		//delete statement doesn't returns anything so we are using
		//TransactionCallbackWithoutResult
		transactionTemplate.execute(new TransactionCallbackWithoutResult() {

		    @Override
		    protected void doInTransactionWithoutResult(TransactionStatus
			    transactionStatus) {
			try {
			    String deletePerson = "DELETE FROM person WHERE id =?";
			    
			    Object[] params = new Object[] { personID };
			    
			    int[] types = new int[] { Types.VARCHAR };
			    
			    jdbcTemplate.update(deletePerson, params, types);
			    System.out.println("\nPerson with id 1 deleted from "
			    	+ "the table\n");
			} catch (Exception e) {
			    transactionStatus.setRollbackOnly();
			}

		    }

		});	

	    }

	  
	    public void selectAllPerson() {

		System.out.println("\nList of person in the table\n");
		String selectAllPerson = "SELECT * FROM person";
		List<Map<String, Object>> listOfPerson = jdbcTemplate.
			queryForList(selectAllPerson);
		for (Iterator<Map<String, Object>> iterator = listOfPerson.
			iterator(); iterator.hasNext();) {
		    Map<String, Object> map = (Map<String, Object>) 
			    iterator.next();
		    System.out.println(map);
		}
		System.out.println();

	    }
	    
	   
	    public void selectPersonByName() {

		System.out.println("\nList of person name Java "
			+ "in the table\n");
		String selectAllPerson = "SELECT * FROM person where "
			+ "First_Name ='Java'";
		List<Map<String, Object>> listOfPerson = jdbcTemplate.
			queryForList(selectAllPerson);
		for (Iterator<Map<String, Object>> iterator = listOfPerson.
			iterator(); iterator.hasNext();) {
		    Map<String, Object> map = (Map<String, Object>) 
			    iterator.next();
		    System.out.println(map);
		}
		System.out.println();

	    }
	    
	    public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
	    }

	    public TransactionTemplate getTransactionTemplate() {
	        return transactionTemplate;
	    }

	    public void setTransactionTemplate(TransactionTemplate transactionTemplate) {
	        this.transactionTemplate = transactionTemplate;
	    }    
	    
}
