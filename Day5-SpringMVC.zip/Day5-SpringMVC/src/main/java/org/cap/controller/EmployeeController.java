package org.cap.controller;

import javax.validation.Valid;

import org.cap.model.Employee;
import org.cap.service.EmployeeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class EmployeeController {
	
	@Autowired
	private EmployeeService employeeService;

	@RequestMapping("/employee")
	public String showEmployeeForm(ModelMap map){
		map.put("employee", new Employee());
		map.put("departs", employeeService.getAllDepartments());
		return "empPage";
	}
	
	@RequestMapping(value="/saveEmp",method=RequestMethod.POST)
	public String saveEmployee(@Valid @ModelAttribute("employee") Employee employee,
			BindingResult results){
		if(results.hasErrors()){
			return "empPage";
		}else{
		System.out.println(employee);
		employeeService.saveEmployee(employee);
		return "showEmp";
		}
	}
}













