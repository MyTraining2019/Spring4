package org.cap.dao;

import java.util.List;

import org.cap.model.Department;
import org.cap.model.Employee;

public interface EmployeeDao {
	
	public void saveEmployee(Employee employee);
	public List<Department> getAllDepartments();

}
