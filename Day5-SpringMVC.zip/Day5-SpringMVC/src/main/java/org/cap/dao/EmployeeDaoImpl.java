package org.cap.dao;

import java.util.List;

import org.cap.model.Department;
import org.cap.model.Employee;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

@Repository
@Qualifier("empDao")
public class EmployeeDaoImpl implements EmployeeDao{

	@Autowired
	private JdbcTemplate jdbcTemp;
	
	public void saveEmployee(Employee employee) {
		String sql="insert into employee(firstName,lastName,salary,email,empDob,empDoj) "
				+ "values(?,?,?,?,?,?)";
		jdbcTemp.update(sql,employee.getFirstName(),employee.getLastName(),
				employee.getSalary(),employee.getEmail(),employee.getEmpDob(),
				employee.getEmpDoj());
		
		/*String sqlDep="insert into department values(?,?)";
		jdbcTemp.update(sqlDep,employee.getDepartment().getDepartmentId(),
				employee.getDepartment().getDepartmentName());
	*/	
	}

	public List<Department> getAllDepartments() {
		
		String sql="select * from department";
		List<Department> departments=jdbcTemp.query(sql, new BeanPropertyRowMapper<>(Department.class));
		
		return departments;
	}

}
