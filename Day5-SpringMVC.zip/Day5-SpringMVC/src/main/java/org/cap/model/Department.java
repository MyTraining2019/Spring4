package org.cap.model;

import org.hibernate.validator.constraints.NotEmpty;

public class Department {
	
	private int departmentId;
	
	@NotEmpty(message="* Please enter Department Name")
	private String departmentName;
	
	public Department(){
		System.out.println("Department No Arg Constructor");
	}
	
	public Department(int departmentId, String departmentName) {
		super();
		this.departmentId = departmentId;
		this.departmentName = departmentName;
	}
	public int getDepartmentId() {
		return departmentId;
	}
	public void setDepartmentId(int departmentId) {
		this.departmentId = departmentId;
	}
	public String getDepartmentName() {
		return departmentName;
	}
	public void setDepartmentName(String departmentName) {
		this.departmentName = departmentName;
	}
	@Override
	public String toString() {
		return "Department [departmentId=" + departmentId + ", departmentName=" + departmentName + "]";
	}
	
	
	

}
