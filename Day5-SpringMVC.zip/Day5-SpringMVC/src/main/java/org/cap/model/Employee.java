package org.cap.model;

import java.util.Date;

import javax.validation.constraints.Future;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Past;

import org.hibernate.validator.constraints.Email;
import org.hibernate.validator.constraints.NotEmpty;
import org.hibernate.validator.constraints.Range;

public class Employee {
	
	private int empId;
	@NotEmpty(message="* Please enter FirstName.")
	private String firstName;
	private String lastName;
	
	@Range(min=2000,max=50000,message="* Salary should be between 2000 and 50000.")
	private double salary;
	
	
	@Email(message="* Please enter valid Email Id.")
	@NotEmpty(message="* Please enter Email Id.")
	private String email;
	
	@Past(message="*Please enter past Date in date of birth.")
	private Date empDob;
	
	@Future(message="*Please enter future Date in date of birth.")
	private Date empDoj;
	
	@NotNull
	private Department department;
	
	public Employee(){
		System.out.println("Employee No Arg Constructor");
	}
	
	
	public Employee(int empId, String firstName, String lastName, double salary) {
		super();
		this.empId = empId;
		this.firstName = firstName;
		this.lastName = lastName;
		this.salary = salary;
	}
	
	
	
	public Employee(int empId, String firstName, String lastName, double salary, String email, Date emoDob, Date emoDoj,
			Department department) {
		super();
		this.empId = empId;
		this.firstName = firstName;
		this.lastName = lastName;
		this.salary = salary;
		this.email = email;
		this.empDob = emoDob;
		this.empDoj = emoDoj;
		this.department = department;
	}


	public int getEmpId() {
		return empId;
	}
	public void setEmpId(int empId) {
		this.empId = empId;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public double getSalary() {
		return salary;
	}
	public void setSalary(double salary) {
		this.salary = salary;
	}
	
	
	public String getEmail() {
		return email;
	}


	public void setEmail(String email) {
		this.email = email;
	}


	public Date getEmpDob() {
		return empDob;
	}


	public void setEmpDob(Date empDob) {
		this.empDob = empDob;
	}


	public Date getEmpDoj() {
		return empDoj;
	}


	public void setEmpDoj(Date empDoj) {
		this.empDoj = empDoj;
	}


	public Department getDepartment() {
		return department;
	}


	public void setDepartment(Department department) {
		this.department = department;
	}


	@Override
	public String toString() {
		return "Employee [empId=" + empId + ", firstName=" + firstName + ", lastName=" + lastName + ", salary=" + salary
				+ ", email=" + email + ", emoDob=" + empDob + ", emoDoj=" + empDoj + ", department=" + department + "]";
	}


	

	
	
	

}
