package org.cap.service;

import java.util.List;

import org.cap.model.Department;
import org.cap.model.Employee;

public interface EmployeeService {
	public void saveEmployee(Employee employee);
	public List<Department> getAllDepartments();
}
