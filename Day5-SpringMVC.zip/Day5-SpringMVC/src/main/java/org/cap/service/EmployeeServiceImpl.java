package org.cap.service;

import java.util.List;

import org.cap.dao.EmployeeDao;
import org.cap.model.Department;
import org.cap.model.Employee;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class EmployeeServiceImpl implements EmployeeService{
	
	@Autowired
	private EmployeeDao employeeDao;

	public void saveEmployee(Employee employee) {
		employeeDao.saveEmployee(employee);
	}

	public List<Department> getAllDepartments() {
		// TODO Auto-generated method stub
		return employeeDao.getAllDepartments();
	}

}
