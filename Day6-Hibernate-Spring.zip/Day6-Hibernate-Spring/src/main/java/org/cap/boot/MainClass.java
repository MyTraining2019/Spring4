package org.cap.boot;

import java.util.Date;
import java.util.List;

import org.cap.config.AppConfig;
import org.cap.model.Employee;
import org.cap.service.EmployeeService;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class MainClass {

	public static void main(String[] args) {
		
		AnnotationConfigApplicationContext context=new AnnotationConfigApplicationContext(AppConfig.class);
		EmployeeService employeeService=(EmployeeService)context.getBean("empService");
	
		Employee employee=new Employee( "Tom", "Jerry", 12000,new Date(),"tom@gmail.com","tom1234");
		Employee employee1=new Employee( "Jack", "Thomson", 23000,new Date(2001, 11, 23),"jack@yahoo.com","jack1234");
		Employee employee2=new Employee( "Emi", "Hendry", 56000,new Date(2018, 3, 1),"emi@gmail.com","emi1234");
		
		
		employeeService.saveEmployee(employee);
		employeeService.saveEmployee(employee1);
		employeeService.saveEmployee(employee2);
		
		
		
		//List All Employee
		
		List<Employee> emps=employeeService.getAllEmployee();
		for(Employee emp:emps)
			System.out.println(emp);
		
		System.out.println("======================");
		/*	
		employeeService.deleteEmployee(2);
		System.out.println("After Deletion");

		List<Employee> employees=employeeService.getAllEmployee();
		for(Employee emp:employees)
			System.out.println(emp);
		
		Employee employee3=employeeService.findEmployee(1);
		System.out.println("Employee Found:" + employee3);*/
		
		employeeService.testCriteria();
		
		
		context.close();
	}

}
