package org.cap.dao;

import java.util.List;

import org.cap.model.Employee;
import org.hibernate.Criteria;
import org.hibernate.SQLQuery;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.springframework.expression.spel.ast.Projection;
import org.springframework.stereotype.Repository;

@Repository
public class EmployeeDaoImpl extends AbstractEmpDao implements EmployeeDao{

	@Override
	public void saveEmployee(Employee employee) {
		getSession().save(employee);
		
	}

	@Override
	public List<Employee> getAllEmployee() {
		
		return getSession().createQuery("select new Employee(empId,firstName,salary) from Employee").list();
	}

	@Override
	public void deleteEmployee(int empId) {
		SQLQuery query= getSession().createSQLQuery("delete from employee_details where empId = :employeeId");
		query.setInteger("employeeId", empId);
		query.executeUpdate();
		
	}

	@Override
	public Employee findEmployee(int empId) {
		
		
		Criteria criteria=getSession().createCriteria(Employee.class);
		criteria.add(Restrictions.eq("empId", empId));
		
		return (Employee)criteria.list().get(0);
	}

	@Override
	public void testCriteria() {
		Criteria criteria=getSession().createCriteria(Employee.class);
		/*criteria.add(Restrictions.and(Restrictions.eq("empId", 2),
				Restrictions.le("salary", 50000.00)));
		List<Employee> employees=criteria.list();
		*/
		
		criteria.setProjection(Projections.property("firstName"));
		
		List<Employee> employees=criteria.list();
		
		System.out.println(employees);
		
	}

}
