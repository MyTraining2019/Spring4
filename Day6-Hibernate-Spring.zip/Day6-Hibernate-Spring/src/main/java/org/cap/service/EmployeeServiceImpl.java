package org.cap.service;

import java.util.List;

import org.cap.dao.EmployeeDao;
import org.cap.model.Employee;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service("empService")
@Transactional
public class EmployeeServiceImpl implements EmployeeService{
	
	@Autowired
	private EmployeeDao employeeDao;

	@Override
	public void saveEmployee(Employee employee) {
		employeeDao.saveEmployee(employee);
	}

	@Override
	public List<Employee> getAllEmployee() {
		
		return employeeDao.getAllEmployee();
	}

	@Override
	public void deleteEmployee(int empId) {
		employeeDao.deleteEmployee(empId);
	}

	@Override
	public Employee findEmployee(int empId) {
		
		return employeeDao.findEmployee(empId);
	}

	@Override
	public void testCriteria() {
		employeeDao.testCriteria();
	}

}
