package org.cap.boot;

import java.util.Date;
import java.util.List;

import org.cap.model.Employee;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.AnnotationConfiguration;
import org.hibernate.tool.hbm2ddl.SchemaExport;

public class TestClass {

	public static void main(String[] args) {
		
		AnnotationConfiguration configuration=new AnnotationConfiguration();
		configuration.addAnnotatedClass(Employee.class);
		configuration.configure("hibernate.cfg.xml");
		
		
		//Re-create Schema
		//new SchemaExport(configuration).create(true, true);
		
		
		
		SessionFactory factory=configuration.buildSessionFactory();
		
		Session session=factory.openSession();
		
		
		session.getTransaction().begin();
		/*
		Employee employee=new Employee( "Tom", "Jerry", 12000,new Date(),"tom@gmail.com","tom1234");
		Employee employee1=new Employee( "Jack", "Thomson", 23000,new Date(2001, 11, 23),"jack@yahoo.com","jack1234");
		Employee employee2=new Employee( "Emi", "Hendry", 56000,new Date(2018, 3, 1),"emi@gmail.com","emi1234");
		
		session.save(employee);
		session.save(employee1);
		session.save(employee2);*/
		
		Employee employee1=(Employee)session.get(Employee.class, 2);
		
		//System.out.println(employee1);
		//session.delete(employee1);
		
		employee1.setSalary(38000);
		session.saveOrUpdate(employee1);
		
		List<Employee> employees=session.createQuery("from Employee").list();
		
		session.getTransaction().commit();
		session.close();
		
		
		for(Employee employee:employees)
			System.out.println(employee);
		
	}

}
