package org.cap.model;

import java.util.Date;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Transient;

@Entity
@Table(name="Employee_Details")
public class Employee {
	
	@Id
	@GeneratedValue
	private int empId;
	
	@Column(name="Emp_firstName",nullable=false)
	private String firstName;
	
	private String lastName;
	
	@Basic
	private double salary;
	
	@Temporal(TemporalType.DATE)
	private Date empDoj;
	
	@Column(nullable=true,unique=true)
	private String email;
	
	@Transient
	private String empPassword;
	
	
	public Employee(){}
	
	public Employee(int empId, String firstName, String lastName, double salary) {
		super();
		this.empId = empId;
		this.firstName = firstName;
		this.lastName = lastName;
		this.salary = salary;
	}
	
	
	public Employee(int empId, String firstName, String lastName, double salary, Date empDoj, String email) {
		super();
		this.empId = empId;
		this.firstName = firstName;
		this.lastName = lastName;
		this.salary = salary;
		this.empDoj = empDoj;
		this.email = email;
	}

	
	
	public Employee(int empId, String firstName, String lastName, double salary, Date empDoj, String email,
			String empPassword) {
		super();
		this.empId = empId;
		this.firstName = firstName;
		this.lastName = lastName;
		this.salary = salary;
		this.empDoj = empDoj;
		this.email = email;
		this.empPassword = empPassword;
	}

	
	
	public Employee(String firstName, String lastName, double salary, Date empDoj, String email, String empPassword) {
		super();
		this.firstName = firstName;
		this.lastName = lastName;
		this.salary = salary;
		this.empDoj = empDoj;
		this.email = email;
		this.empPassword = empPassword;
	}

	public int getEmpId() {
		return empId;
	}
	public void setEmpId(int empId) {
		this.empId = empId;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public double getSalary() {
		return salary;
	}
	public void setSalary(double salary) {
		this.salary = salary;
	}
	
	
	
	public Date getEmpDoj() {
		return empDoj;
	}

	public void setEmpDoj(Date empDoj) {
		this.empDoj = empDoj;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}
	
	

	public String getEmpPassword() {
		return empPassword;
	}

	public void setEmpPassword(String empPassword) {
		this.empPassword = empPassword;
	}

	@Override
	public String toString() {
		return "Employee [empId=" + empId + ", firstName=" + firstName + ", lastName=" + lastName + ", salary=" + salary
				+ ", empDoj=" + empDoj + ", email=" + email + ", empPassword=" + empPassword + "]";
	}

	

}
