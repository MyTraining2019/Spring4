package org.cap.boot;

import java.util.ArrayList;
import java.util.List;

import org.cap.model.Product;
import org.cap.service.ProductService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.stereotype.Controller;
//@Controller
public class MainClass {
/*
	@Autowired
	private static ProductService productService;*/
	
	public static void main(String[] args) {
	
		ClassPathXmlApplicationContext ctx=new ClassPathXmlApplicationContext("myBeans.xml");
		
		
		
		ProductService productService=(ProductService)ctx.getBean("productService");
		
		Product product=new Product(11, "Mobile");
		productService.saveProduct(product);
		
		Product product2=new Product(22, "Samsung");
		Product product3=new Product(33, "Apple");
		Product product4=new Product(44, "Oppo");
		
		List<Product> products=new ArrayList<>();
		products.add(product4);
		products.add(product2);
		products.add(product3);
		
		
		productService.saveAllProduct(products);
		
		
		Product find_product=productService.find(22);
		
		System.out.println("Product Found:" + find_product);
		
		
		List<Product> products2=productService.findByProductName("p");
		
		System.out.println(products2);
		
		
		List<Product> sear_products=productService.searchProduct(1, "Mobile");
		
		System.out.println("Result =====> " + sear_products);
		ctx.close();
	}

}
