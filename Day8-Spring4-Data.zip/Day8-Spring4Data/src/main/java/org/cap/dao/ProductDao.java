package org.cap.dao;

import java.util.List;

import org.cap.model.Product;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

@Repository
public interface ProductDao extends JpaRepository<Product, Integer> {

	public List<Product> findByProductNameIgnoreCase(String searchString);
	
	@Query("select p from Product p where p.productId=:prodId and p.productName=:prodName")
	public List<Product> searchProduct(@Param("prodId")int prodId,@Param("prodName") String prodName);
 }
