package org.cap.service;

import java.util.List;

import org.cap.model.Product;

public interface ProductService {
	
	public void saveProduct(Product product);
	public void saveAllProduct(List<Product> products);

	public Product find(int productId);
	
	public List<Product> findByProductName(String searchString);
	public List<Product> searchProduct(int prodId, String prodName );
}
