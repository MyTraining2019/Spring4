package org.cap.service;

import java.util.List;

import org.cap.dao.ProductDao;
import org.cap.model.Product;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service("productService")
@Transactional
public class ProductServiceImpl implements ProductService {

	@Autowired
	private ProductDao productDao;
	
	@Override
	public void saveProduct(Product product) {
		productDao.save(product);
	}

	@Override
	public void saveAllProduct(List<Product> products) {
		for(Product product:products)
			productDao.save(product);
	}

	@Override
	public Product find(int productId) {
		
		return productDao.findOne(productId);
	}

	@Override
	public List<Product> findByProductName(String searchString) {
		return productDao.findByProductNameIgnoreCase(searchString);
	}

	@Override
	public List<Product> searchProduct(int prodId, String prodName) {
		
		return productDao.searchProduct(prodId, prodName);
	}

}
